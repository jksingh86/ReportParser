package easyupload.utils;

import java.io.File;
import java.io.FilenameFilter;

import com.fasterxml.jackson.core.sym.Name;

public class FileFilter implements FilenameFilter {

	private String fileCompleteName;
	private String fileName;
	private String fileType;

	// constructor takes string argument
	public FileFilter(String name,String ext) {
		fileName = name;
		fileType = ext;
		fileCompleteName = name + "." + ext;
	}
	
	public FileFilter(String ext) {
		fileType = ext;
	}
	
	public boolean isOnlyExtension(){
		return fileName == null;
	}

	@Override
	public boolean accept(File dir, String name) {
		if(isOnlyExtension())
			return name.endsWith(fileType);
		else
			return name.equalsIgnoreCase(fileCompleteName);
	}
}