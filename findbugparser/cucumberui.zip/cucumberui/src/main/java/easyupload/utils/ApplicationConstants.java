package easyupload.utils;

public class ApplicationConstants {
	public static final String DEMO_USER				= "Demo";
	public static final String PROPERTIES_SEPARATOR		= "-:-";

	public static final String UUID_DATE_FORMAT			= "yyyy_MM_dd_HH_mm_ss_SSS";

	public static final String HASH						= "#";
	public static final String BLANK					= "";
	public static final String DATE_FORMAT				= "yyyy/MM/dd HH:mm:ss";
	public static final String STATUS_QUEUED			= "QUEUED";
	public static final String STATUS_RUNNING			= "RUNNING";
	public static final String STATUS_COMPLETED			= "COMPLETED";
	public static final String STRING_FILES				= "files";
	public static final String STRING_COMMA				= ",";
	public static final String HTML_NEW_LINE			= "<br>";
}
