package easyupload.utils;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.exec.ExecuteException;
import org.apache.commons.exec.LogOutputStream;
import org.apache.commons.exec.PumpStreamHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ch.qos.logback.classic.Level;
import easyupload.entity.CucumberFeature;
import easyupload.entity.JUnitSuite;
import easyupload.entity.TestGroup;
import easyupload.exception.FileNotFoundException;

public class ApplicationUtils {
	private static final Logger logger = LoggerFactory.getLogger(ApplicationUtils.class);

	public static String dateToString(Date date) {
		String dateString = "";

		if (date != null) {
			dateString = getSimpleDateFormat().format(date);
		}

		return dateString;
	}

	public static Date stringToDate(String dateString) {
		Date date = null;
		try {
			if (dateString != null)
				date = getSimpleDateFormat().parse(dateString);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		return date;
	}

	public static SimpleDateFormat getSimpleDateFormat() {
		return new SimpleDateFormat(ApplicationConstants.DATE_FORMAT);
	}

	public static PumpStreamHandler currentLogStreamHandler() {
		// final Map<String, String> loggerContextMap = MDC.getCopyOfContextMap();
		return new PumpStreamHandler(new LogOutputStream() {
			@Override
			protected void processLine(String line, int intLevel) {
				// MDC.setContextMap(loggerContextMap);
				if (Level.ERROR_INT == intLevel) {
					logger.error(line);
				} else if (Level.WARN_INT == intLevel) {
					logger.warn(line);
				} else if (Level.DEBUG_INT == intLevel) {
					logger.debug(line);
				} else {
					logger.info(line);
				}
			}
		});
	}

	public static final int executeAsCommand(String command) throws FileNotFoundException, IOException {
		CommandLine cmdLine = CommandLine.parse(command);
		DefaultExecutor defaultExecutor = new DefaultExecutor();
		defaultExecutor.setExitValue(0);
		defaultExecutor.setStreamHandler(currentLogStreamHandler());

		int exitCode = 0;
		try {
			exitCode = defaultExecutor.execute(cmdLine);
			logger.info("Process [{}] finished with [{}] as exit code.", command, exitCode);
		} catch (IOException ex) {
			if (ex instanceof ExecuteException) {
				int exitValue = ((ExecuteException) ex).getExitValue();
				if (exitValue == 1) {
					throw new FileNotFoundException();
				} else {
					throw ex;
				}
			} else {
				throw ex;
			}
		}
		return exitCode;
	}

	public static List<String> stringToList (String string, String separator) {
		return Arrays.asList(string.split(separator));
	}

	public static String listToString (List<String> list, String separator) {
		StringBuilder returnList;
		returnList = new StringBuilder();

		if (list != null) {
			for (String val: list) {
				returnList.append(val).append(separator);
			}

			if (returnList.toString().endsWith(separator)) {
				returnList.setLength(returnList.length()-1);
			}
		}

		return returnList.toString();
	}

	public static List<CucumberFeature> listToFeatures (List<String> list) {
		List<CucumberFeature> featureList;
		featureList = new ArrayList<CucumberFeature>();

		if (list != null ) {
			for (String feature: list) {
				featureList.add(new CucumberFeature(feature, feature));
			}
		}

		return featureList;
	}

	public static List<JUnitSuite> listToJUnits (List<String> list) {
		List<JUnitSuite> featureList;
		featureList = new ArrayList<JUnitSuite>();

		if (list != null ) {
			for (String feature: list) {
				featureList.add(new JUnitSuite(feature, feature));
			}
		}

		return featureList;
	}

	public static List<TestGroup> listToTestGroups (List<String> list) {
		List<TestGroup> testGroupList;
		testGroupList = new ArrayList<TestGroup>();

		if (list != null ) {
			for (String testGroup: list) {
				testGroupList.add(new TestGroup(testGroup, testGroup));
			}
		}

		return testGroupList;
	}
}
