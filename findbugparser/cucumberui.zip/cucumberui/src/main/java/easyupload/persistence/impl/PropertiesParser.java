package easyupload.persistence.impl;

import static easyupload.utils.ApplicationConstants.BLANK;
import static easyupload.utils.ApplicationConstants.PROPERTIES_SEPARATOR;
import static easyupload.utils.ApplicationConstants.STRING_COMMA;

import org.springframework.util.StringUtils;

import easyupload.service.ServiceCall;
import easyupload.utils.ApplicationUtils;

public class PropertiesParser {
	public static ServiceCall parseProperty(String key, String property) {
		String valArray[];
		ServiceCall call;
		call = new ServiceCall();

		if (property != null) {
			valArray = property.split(PROPERTIES_SEPARATOR);

			call.setUuid(key);

			if (valArray != null && valArray.length >= 1) {
				call.setStatus(valArray[0]);
			}

			if (valArray != null && valArray.length >= 2) {
				call.setUser(valArray[1]);
			}

			if (valArray != null && valArray.length >= 3 && !StringUtils.isEmpty(valArray[2])) {
				call.setStartDate(ApplicationUtils.stringToDate(valArray[2]));
			}

			if (valArray != null && valArray.length >= 4 && !StringUtils.isEmpty(valArray[3])) {
				call.setEndDate(ApplicationUtils.stringToDate(valArray[3]));
			}

			if (valArray != null && valArray.length >= 5 && !StringUtils.isEmpty(valArray[4])) {
				call.setTestGroupList(ApplicationUtils.stringToList(valArray[4], STRING_COMMA));
			}
		}

		return call;
	}

	public static String toProperty(ServiceCall call) {
		StringBuilder property;
		property = new StringBuilder();

		if (call != null) {
			property.append(call.getStatus());
			property.append(PROPERTIES_SEPARATOR).append(call.getUser());

			if (call.getStartDate() != null) {
				property.append(PROPERTIES_SEPARATOR).append(ApplicationUtils.dateToString(call.getStartDate()));
			} else {
				property.append(PROPERTIES_SEPARATOR).append(BLANK);
			}

			if (call.getEndDate() != null) {
				property.append(PROPERTIES_SEPARATOR).append(ApplicationUtils.dateToString(call.getEndDate()));
			} else {
				property.append(PROPERTIES_SEPARATOR).append(BLANK);
			}

			if (call.getTestGroupList() != null) {
				property.append(PROPERTIES_SEPARATOR)
						.append(ApplicationUtils.listToString(call.getTestGroupList(), STRING_COMMA));
			} else {
				property.append(PROPERTIES_SEPARATOR).append(BLANK);
			}
		}

		return property.toString();
	}
}
