package easyupload.persistence;

import java.util.List;

import easyupload.entity.TestGroup;
import easyupload.service.ServiceCall;

public interface ServiceCallPersistence {
	public void init();
	public void save(ServiceCall serviceCall);
	public String getStatus(String uuid);
	public List<TestGroup> listSelectedTestGroup(String uuid);
	public int countServiceCall();
	public List<ServiceCall> listServiceCall(String status);
	public List<ServiceCall> listAllServiceCall();
	public List<ServiceCall> listFilteredServiceCall(int start, int length);
}
