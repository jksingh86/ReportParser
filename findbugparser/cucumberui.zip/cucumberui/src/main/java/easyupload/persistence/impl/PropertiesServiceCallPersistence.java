package easyupload.persistence.impl;

import static easyupload.utils.ApplicationConstants.PROPERTIES_SEPARATOR;
import static easyupload.utils.ApplicationConstants.STATUS_QUEUED;
import static easyupload.utils.ApplicationConstants.STATUS_RUNNING;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import easyupload.entity.TestGroup;
import easyupload.persistence.ServiceCallPersistence;
import easyupload.service.ServiceCall;
import easyupload.utils.ApplicationUtils;

public class PropertiesServiceCallPersistence implements ServiceCallPersistence {

	private Properties props;
	private String propFileName = "servicecall.properties";
	private static final ReadWriteLock READ_WRITE_LOCK = new ReentrantReadWriteLock();
	private File propertyFile;
	private boolean init = false;

	public PropertiesServiceCallPersistence(String baseDir) {
		FileInputStream fIn = null;

		try {
			propertyFile = Paths.get(baseDir.concat(File.separator).concat(propFileName)).toFile();

			if (!propertyFile.exists()) {
				propertyFile.createNewFile();
			}

			fIn = new FileInputStream(propertyFile);
			props = new Properties();
			props.load(fIn);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			closeStreams(fIn, null);
		}

		init();
	}

	@Override
	public void save(ServiceCall serviceCall) {
		READ_WRITE_LOCK.writeLock().lock();
		;
		OutputStream os = null;

		try {
			os = new FileOutputStream(propertyFile);
			String property = PropertiesParser.toProperty(serviceCall);
			props.setProperty(serviceCall.getUuid(), property);
			props.store(os, null);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			READ_WRITE_LOCK.writeLock().unlock();
			closeStreams(null, os);
		}
	}

	@Override
	public String getStatus(String uuid) {
		READ_WRITE_LOCK.readLock().lock();
		String status = null;

		try {
			status = PropertiesParser.parseProperty(uuid, props.getProperty(uuid)).getStatus();
		} finally {
			READ_WRITE_LOCK.readLock().unlock();
		}

		return status;
	}

	@Override
	public List<ServiceCall> listServiceCall(String status) {
		List<ServiceCall> list;
		list = new ArrayList<ServiceCall>();

		Set<Object> keys = props.keySet();
		Iterator<Object> iterator = keys.iterator();

		while (iterator.hasNext()) {
			String uuid = iterator.next().toString();
			String value = props.getProperty(uuid);
			ServiceCall call = PropertiesParser.parseProperty(uuid, value);
			String callStatus = call.getStatus();

			if (status != null && callStatus != null && status.trim().equals(callStatus.trim())) {
				list.add(call);
			}
		}

		return list;
	}

	@Override
	public void init() {
		if (!init) {
			Set<Object> keys = props.keySet();
			Iterator<Object> iterator = keys.iterator();

			while (iterator.hasNext()) {
				String uuid = iterator.next().toString();
				String value = props.getProperty(uuid);

				if (value != null && value.startsWith(STATUS_RUNNING)) {
					value = STATUS_QUEUED.concat(value.substring(value.indexOf(PROPERTIES_SEPARATOR)));
					props.setProperty(uuid, value);
				}
			}

			save();
			init = true;
		}
	}

	private void save() {
		OutputStream os = null;

		try {
			os = new FileOutputStream(propertyFile);
			props.store(os, null);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			closeStreams(null, os);
		}
	}

	private void closeStreams(InputStream is, OutputStream os) {
		if (is != null) {
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		if (os != null) {
			try {
				os.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public List<ServiceCall> listAllServiceCall() {
		List<ServiceCall> list;
		list = new ArrayList<ServiceCall>();

		Set<Object> keys = props.keySet();
		Iterator<Object> iterator = keys.iterator();

		while (iterator.hasNext()) {
			String uuid = iterator.next().toString();
			String value = props.getProperty(uuid);

			ServiceCall serviceCall;
			serviceCall = PropertiesParser.parseProperty(uuid, value);
			list.add(serviceCall);
		}

		list.sort(new Comparator<ServiceCall>() {
			@Override
			public int compare(ServiceCall s1, ServiceCall s2) {
				if (s1.getStartDate().after(s2.getStartDate())) {
					return -1;
				} else if (s1.getStartDate().getTime() == s2.getStartDate().getTime()) {
					return 0;
				} else {
					return 1;
				}
			}
		});

		return list;
	}

	@Override
	public int countServiceCall() {
		return props.size();
	}

	@Override
	public List<ServiceCall> listFilteredServiceCall(int start, int length) {
		List<ServiceCall> list;
		list = listAllServiceCall();

		if (list.size() >= start + length) {
			list = list.subList(start, start + length);
		} else {
			list = list.subList(start, list.size());
		}

		return list;
	}

	@Override
	public List<TestGroup> listSelectedTestGroup(String uuid) {
		READ_WRITE_LOCK.readLock().lock();
		List<TestGroup> testGroupList = null;

		try {
			testGroupList = ApplicationUtils
					.listToTestGroups(PropertiesParser.parseProperty(uuid, props.getProperty(uuid)).getTestGroupList());
		} finally {
			READ_WRITE_LOCK.readLock().unlock();
		}

		return testGroupList;
	}
}
