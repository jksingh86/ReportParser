package easyupload.exception;

public class FileNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6731916508904907090L;

}
