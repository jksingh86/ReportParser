package easyupload.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.Scope;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;
import org.springframework.web.servlet.view.UrlBasedViewResolver;

import easyupload.entity.SessionAttributes;
import easyupload.interceptor.LoginInterceptor;
import easyupload.persistence.ServiceCallPersistence;
import easyupload.persistence.impl.PropertiesServiceCallPersistence;
import easyupload.service.ServiceCallManager;
import easyupload.service.ServiceCaller;
import easyupload.service.WatcherService;
import easyupload.service.impl.UserServiceImpl;
import jks.dao.TestCaseReportMongoRepository;

@EnableWebMvc
@Configuration
@ComponentScan(basePackages = "easyupload", excludeFilters = @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = ApplicationConfig.class))
public class ApplicationConfig extends WebMvcConfigurerAdapter {
	@Value("${base.dir}")
	private String baseDir;

	@Value("${watch.dirs}")
	private String watchDirs;

	@Bean
	public static PropertySourcesPlaceholderConfigurer properties() {
		PropertySourcesPlaceholderConfigurer configurer = new PropertySourcesPlaceholderConfigurer();
		configurer.setLocations(new ClassPathResource("application-config.properties"));
		configurer.setIgnoreUnresolvablePlaceholders(true);
		configurer.setIgnoreResourceNotFound(true);
		return configurer;
	}

	@Bean
	public UrlBasedViewResolver urlBasedViewResolver() {
		UrlBasedViewResolver res = new InternalResourceViewResolver();
		res.setViewClass(JstlView.class);
		res.setPrefix("/WEB-INF/web/easyupload/");
		res.setSuffix(".jsp");

		return res;
	}
	
	@Bean("serviceCallPersistence")
	public ServiceCallPersistence getServiceCallPersistence() {
		return new PropertiesServiceCallPersistence(baseDir);
	}

	@Bean
	public ServiceCaller getServiceCaller() {
		return new ServiceCaller();
	}

	@Bean("multipartResolver")
	public CommonsMultipartResolver commonsMultipartResolver() {
		CommonsMultipartResolver commonsMultipartResolver = new CommonsMultipartResolver();
		commonsMultipartResolver.setMaxUploadSize(10000000000L);
		return commonsMultipartResolver;
	}

	@Bean
	public ServiceCallManager getServiceCallManager() {
		return new ServiceCallManager(getServiceCallPersistence(), getServiceCaller());
	}

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		// registry.addResourceHandler("/api/static/**").addResourceLocations("/WEB-INF/web/easyupload/static/");
		registry.addResourceHandler("/css/**").addResourceLocations("/WEB-INF/web/easyupload/static/css/");
		registry.addResourceHandler("/js/**").addResourceLocations("/WEB-INF/web/easyupload/static/js/");
		registry.addResourceHandler("/images/**").addResourceLocations("/WEB-INF/web/easyupload/static/images/");
		registry.addResourceHandler("/fonts/**").addResourceLocations("/WEB-INF/web/easyupload/static/fonts/");
	}

	@Bean
	public WatcherService getWatcherService () {
		WatcherService service;

		service = new WatcherService(watchDirs);
		service.registerPaths();
		return service;
	}

	@Bean("sessionAttributes")
	@Scope("session")
	public SessionAttributes getSessionAttributes() {
		return new SessionAttributes();
	}

	@Bean("userService")
	public UserServiceImpl getUserServiceImpl() {
		return new UserServiceImpl();
	}

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(new LoginInterceptor()).addPathPatterns("/**").excludePathPatterns("/**/logMeIn")
				.excludePathPatterns("/**/loginForm");
	}
}
