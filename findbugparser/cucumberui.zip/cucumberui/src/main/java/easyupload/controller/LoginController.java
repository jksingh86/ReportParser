package easyupload.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import easyupload.entity.LoginUser;
import easyupload.entity.SessionAttributes;
import easyupload.entity.User;
import easyupload.service.IUserService;

@Controller
@Scope("request")
public class LoginController {
	private final Logger logger = LoggerFactory.getLogger(LoginController.class);

	@Autowired
	SessionAttributes sessionAttributes; 

	@Autowired
	IUserService userService;

	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public String uploadFiles() {
		logger.info("uploadFiles Start:");
		return "index";
	}
	@RequestMapping(value = "/logMeIn", method = RequestMethod.POST)
	public String loginProcess(HttpServletRequest request, HttpServletResponse response, @ModelAttribute("login") LoginUser login) {
		logger.info("logMeIn Starts : userName : " + login.getUsername());
		String returnVal = null;
		User user = userService.getUser(login);

		if (null != user && user.getUserName()!=null) {
			sessionAttributes.setUser(user.getUserName());
			request.getSession().setAttribute("sessionAttributes", sessionAttributes);
			returnVal ="index";
		} else {
			returnVal ="loginForm";
		}

		logger.info("logMeIn Ends");
		return returnVal;
	}

	@RequestMapping(value = "/loginForm", method = RequestMethod.GET)
	public String login(HttpServletRequest request, HttpServletResponse response) {
		logger.info("loginForm Starts :");
		String returnVal = null;
		SessionAttributes sessionAtrib = (SessionAttributes) request.getSession().getAttribute("sessionAttributes");
		
		if (sessionAtrib!=null && sessionAtrib.getUser() != null) {
			returnVal ="index";
		} else {
			returnVal ="loginForm";
		}

		logger.info("loginForm Ends");
		return returnVal;
	}
	
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logoutUser(HttpServletRequest request, HttpServletResponse response) {
		logger.info("loginForm Starts :");
		request.getSession().invalidate();
		logger.info("loginForm Ends");
		return "loginForm";
	}
}
