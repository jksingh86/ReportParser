package easyupload.controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import easyupload.entity.FileDetails;
import easyupload.utils.ApplicationConstants;
import easyupload.utils.FileFilter;

@Controller
public class HelpController {
	private final Logger logger = LoggerFactory.getLogger(HelpController.class);

	@Value("${support.dir}")
	String supportdir;

	@Value("${sample.dir}")
	String sampledir;

	@RequestMapping(value = "/listFiles", method = RequestMethod.GET)
	@ResponseBody
	public String getFileList() throws IOException {
		logger.info("getFileList Start:");
		ObjectMapper mapperObj = new ObjectMapper();
		String jsonStr = "{}";
		Map<String, List<FileDetails>> mapFileList = new LinkedHashMap<>();

		Path path = Paths.get(supportdir);
		List<Path> pathList = listAllFolder(path); // list all folder in base directory

		pathList.stream().forEach(e -> {
			List<FileDetails> fileList = traverseDir(e);// traverse all folder and get files to make Map
			mapFileList.put(e.getFileName().toString(), fileList);
		});
		try {
			jsonStr = mapperObj.writeValueAsString(mapFileList);
			logger.info(jsonStr);
		} catch (JsonProcessingException e) {
			logger.error(e.getMessage());
		}

		return jsonStr;
	}

	/**
	 * Traverse the given path for files
	 * 
	 * @param path
	 * @return
	 */
	private List<FileDetails> traverseDir(Path path) {
		List<FileDetails> fileList = new ArrayList<FileDetails>();

		try (DirectoryStream<Path> stream = Files.newDirectoryStream(path)) {
			for (Path entry : stream) {
				if (!entry.toFile().isDirectory()) {
					File file = entry.toFile();
					FileDetails fd = new FileDetails(file.getName(), String.valueOf(file.length()), resolvePath(file, new File(supportdir)), null);
					fileList.add(fd);
				}
			}
		} catch (IOException e) {
			logger.error(e.getMessage());
		}

		return fileList;
	}

	/**
	 * Find and list all folder in base directory
	 * 
	 * @param path
	 * @return
	 * @throws IOException
	 */
	private List<Path> listAllFolder(Path path){
		Deque<Path> stack = new ArrayDeque<Path>();
		stack.push(path);
		List<Path> pathList = new ArrayList<Path>();
		pathList.add(path);

		while (!stack.isEmpty()) {
			try (DirectoryStream<Path> stream = Files.newDirectoryStream(stack.pop());) {
				for (Path entry : stream) {
					if (Files.isDirectory(entry)) {
						stack.push(entry);
						pathList.add(entry);
					}
				}
			}catch(IOException e) {
				logger.error(e.getMessage());
			}
		}
		return pathList;
	}

	@RequestMapping(value = "/sampleFeature", method = RequestMethod.GET)
	@ResponseBody
	public String sampleFeatureFiles() {
		logger.info("getFileList Start:");
		ObjectMapper mapperObj = new ObjectMapper();
		String jsonStr = "{}";

		FilenameFilter featureFilter = new FileFilter("feature");
		File[] files = new File(sampledir).listFiles(featureFilter);
		List<FileDetails> fileList = getFeatureFilesDetails(files);

		try {
			jsonStr = mapperObj.writeValueAsString(fileList);
		} catch (JsonProcessingException e) {
			logger.error(e.getMessage());
		}
		return jsonStr;
	}

	private List<FileDetails> getFeatureFilesDetails(File[] files) {
		List<FileDetails> fileList = new ArrayList<FileDetails>();

		for (File file : files) {
			try (BufferedReader reader = new BufferedReader(new FileReader(file));) {
				StringBuilder fileContents = new StringBuilder();
				Stream<String> fileContentStream = reader.lines();
				fileContentStream.forEach(l -> fileContents.append(l).append(System.lineSeparator()));

				String featureHelpTxt = fetchFeatureHelpFileIfAny(file.getName(), "txt");
				fileList.add(new FileDetails(file.getName(), fileContents.toString(), resolvePath(file, new File(sampledir)), featureHelpTxt));
			} catch (IOException e) {
				logger.error(e.getMessage());
			}
		}
		return fileList;
	}

	private String resolvePath(File fileAbsolutePath, File baseFolder) {
        Path pathAbsolute = Paths.get(fileAbsolutePath.getAbsolutePath());
        Path pathBase = Paths.get(baseFolder.getAbsolutePath());
        Path pathRelative = pathBase.relativize(pathAbsolute);
        logger.info("fileAbsolutePath: " + fileAbsolutePath + " baseFolder: " + baseFolder + " pathRelative: " + pathRelative);
		return pathRelative.toString();
	}

	private String fetchFeatureHelpFileIfAny(String name, String type) {
		name = name.replace(".feature", "");
		FilenameFilter txtFilter = new FileFilter(name, type);
		File[] oneFile = new File(sampledir).listFiles(txtFilter);

		if (oneFile.length > 0) {
			try (BufferedReader txtReader = new BufferedReader(new FileReader(oneFile[0]));) {
				StringBuilder txtFileContents = new StringBuilder();
				Stream<String> txtFileContentStream = txtReader.lines();
				txtFileContentStream.forEach(l -> txtFileContents.append(l).append(ApplicationConstants.HTML_NEW_LINE));
				return txtFileContents.toString();
			} catch (IOException e) {
				logger.error(e.getMessage());
			}
		}

		return null;
	}

	@RequestMapping(value = "/downloadSupportFile", method = RequestMethod.GET, produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	@ResponseBody
	public FileSystemResource downloadSupportFile(@RequestParam("filename") String fileName, HttpServletResponse response) {
		File downloadFile = new File(supportdir.concat(File.separator).concat(fileName));
		logger.info("downloading file : " + supportdir.concat(File.separator).concat(fileName));
		String fileDisplayName;

		if (fileName.indexOf(File.separator) > -1) {
			fileDisplayName =  fileName.substring(fileName.indexOf(File.separator)+1);
		} else {
			fileDisplayName =  fileName;
		}

		logger.info("downloading fileName: " + fileName + " fileDisplayName: " + fileDisplayName);
		response.setHeader("Content-Disposition", "attachment; filename=\"" + fileDisplayName + "\"");
		return new FileSystemResource(downloadFile);
	}

	@RequestMapping(value = "/downloadSampleFile", method = RequestMethod.GET, produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	@ResponseBody
	public FileSystemResource downloadSampleFile(@RequestParam("filename") String fileName, HttpServletResponse response) {
		File downloadFile = new File(sampledir.concat(File.separator).concat(fileName));
		logger.info("downloading file : " + sampledir.concat(File.separator).concat(fileName));
		String fileDisplayName;

		if (fileName.indexOf(File.separator) > -1) {
			fileDisplayName =  fileName.substring(fileName.indexOf(File.separator)+1);
		} else {
			fileDisplayName =  fileName;
		}

		logger.info("downloading fileName: " + fileName + " fileDisplayName: " + fileDisplayName);
		response.setHeader("Content-Disposition", "attachment; filename=\"" + fileDisplayName + "\"");
		return new FileSystemResource(downloadFile);
	}

	public static void main(String[] args) {
		HelpController obj = new HelpController();
		obj.resolvePath(new File("C:\\work\\ravindra\\config\\automation-ui\\supportFiles\\ccdm-job1\\Test-CCDM.sql"), new File("C:\\work\\ravindra\\config\\automation-ui\\supportFiles"));
	}
}
