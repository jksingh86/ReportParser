package easyupload.controller;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class UtilController {
	private final Logger logger = LoggerFactory.getLogger(UtilController.class);

	@RequestMapping(value = "/getHistory", method = RequestMethod.GET)
	public String getTestHistory() throws IOException {
		logger.info("getTestHistory Start:");

		return "history";
	}

	@RequestMapping(value = "/help", method = RequestMethod.GET)
	public String getHelp() {
		logger.info("getFileList Start:");
		return "help";
	}

	@RequestMapping(value = "/supportFile", method = RequestMethod.GET)
	public String downloadSupportFile() {

		return "supportedFile";
	}
	
	@RequestMapping(value = "/sampleFile", method = RequestMethod.GET)
	public String downloadSampleFile() {

		return "sampleFile";
	}
}
