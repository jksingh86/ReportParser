package easyupload.controller;

import static easyupload.utils.ApplicationConstants.DEMO_USER;
import static easyupload.utils.ApplicationConstants.STATUS_QUEUED;
import static easyupload.utils.ApplicationConstants.STRING_COMMA;
import static easyupload.utils.ApplicationConstants.STRING_FILES;
import static easyupload.utils.ApplicationConstants.UUID_DATE_FORMAT;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import easyupload.entity.FileUpload;
import easyupload.entity.TestGroup;
import easyupload.service.FileUploadService;
import easyupload.service.ServiceCall;
import easyupload.service.ServiceCallManager;
import easyupload.service.ServiceCallResponse;
import easyupload.service.WatcherService;
import easyupload.utils.ApplicationUtils;

@CrossOrigin
@Controller
public class FileController {

	private final Logger logger = LoggerFactory.getLogger(FileController.class);

	@Autowired
	FileUploadService fileUploadService;

	@Autowired
	WatcherService watcherService;

	@Autowired
	ServiceCallManager serviceCallManager;

	@Value("${base.dir}")
	String baseDir;

	@Value("${test.groups.file}")
	String testGroupFile;

	private String testGroupList;

	@RequestMapping(value = "/generateId", method = RequestMethod.GET)
	@ResponseBody
	public String generateUuid() {
		String dateFormat = UUID_DATE_FORMAT;
		SimpleDateFormat format;
		String uuid;

		format = new SimpleDateFormat(dateFormat);
		uuid = format.format(new Date());
		uuid = uuid.concat("_").concat(Integer.toString((int) Math.floor((Math.random() * 1000000) + 1)));
		return uuid;
	}

	@RequestMapping(value = "/getstatus/{uuid}", method = RequestMethod.GET)
	@ResponseBody
	public String getStatus(@PathVariable String uuid) {
		return serviceCallManager.getStatus(uuid);
	}

	@RequestMapping(value = "/upload", headers = "content-type=multipart/*", method = RequestMethod.POST)
	public ResponseEntity<String> uploadFile(
			@RequestParam(value = "selectedTestGroup", required = false) String selectedTestGroup,
			MultipartHttpServletRequest request) {
		logger.info("upload start: selectedTestGroup: " + selectedTestGroup);
		String uuid;
		List<String> testGroupList;

		uuid = generateUuid();

		try {
			File parentDir = new File(
					baseDir.concat(File.separator).concat(uuid.concat(File.separator).concat(STRING_FILES)));

			if (!parentDir.exists()) {
				parentDir.mkdirs();
			}

			Iterator<String> itr = request.getFileNames();

			while (itr.hasNext()) {
				String uploadedFile = itr.next();
				MultipartFile file = request.getFile(uploadedFile);
				String mimeType = file.getContentType();
				String filename = file.getOriginalFilename();
				byte[] bytes = file.getBytes();

				FileUpload newFile = new FileUpload(uuid, filename, bytes, mimeType);
				fileUploadService.uploadFile(newFile);
			}

			if (selectedTestGroup != null) {
				testGroupList = ApplicationUtils.stringToList(selectedTestGroup, STRING_COMMA);
			} else {
				testGroupList = null;
			}

			ServiceCall call = new ServiceCall(uuid, STATUS_QUEUED, DEMO_USER, new Date(), null, testGroupList);
			serviceCallManager.submitServiceCall(call);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>("{}", HttpStatus.INTERNAL_SERVER_ERROR);
		}

		StringBuilder jsonResponse = new StringBuilder();
		jsonResponse.append("{\"uuid\": \"").append(uuid).append("\"}");
		logger.info("upload : Ends");
		return new ResponseEntity<>(jsonResponse.toString(), HttpStatus.OK);
	}

	@RequestMapping(value = "/history", method = RequestMethod.GET)
	@ResponseBody
	public String getHistory(@RequestParam("start") int start, @RequestParam("length") int length,
			@RequestParam("draw") int draw) {
		ObjectMapper mapperObj = new ObjectMapper();
		List<ServiceCall> list;
		ServiceCallResponse response;
		String jsonStr = "{}";
		int totalRecords = 0;

		mapperObj.setDateFormat(ApplicationUtils.getSimpleDateFormat());
		totalRecords = serviceCallManager.countServiceCall();
		list = serviceCallManager.listFilteredServiceCall(start, length);
		response = new ServiceCallResponse(list, draw, totalRecords, totalRecords);

		try {
			jsonStr = mapperObj.writeValueAsString(response);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}

		return jsonStr;
	}

	@RequestMapping(value = "/listTestGroup", method = RequestMethod.GET)
	@ResponseBody
	public String getTestGroups() {
		List<TestGroup> testGroupList;
		ObjectMapper mapperObj;
		List<String> junitListString;
		String jsonStr = "{}";
		logger.debug("listTestGroups:: started: ");

		testGroupList = new ArrayList<TestGroup>();
		mapperObj = new ObjectMapper();

		junitListString = ApplicationUtils.stringToList(readTestGroups(), STRING_COMMA);

		for (String junit : junitListString) {
			testGroupList.add(new TestGroup(junit, junit));
		}

		try {
			jsonStr = mapperObj.writeValueAsString(testGroupList);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}

		logger.info("listTestGroups:: jsonStr: " + jsonStr);
		return jsonStr;
	}

	@RequestMapping(value = "/selectedTestGroups/{uuid}", method = RequestMethod.GET)
	@ResponseBody
	public String getSelectedTestGroups(@PathVariable String uuid) {
		List<TestGroup> testGroupList;
		ObjectMapper mapperObj;

		String jsonStr = "{}";

		if (uuid != null) {
			testGroupList = serviceCallManager.listSelectedTestGroup(uuid);
			mapperObj = new ObjectMapper();

			try {
				jsonStr = mapperObj.writeValueAsString(testGroupList);
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
		}

		logger.info("selectedTestGroups uuid: " + uuid + " jsonStr: " + jsonStr);
		return jsonStr;
	}

	public String readTestGroups() {
		StringBuilder testGroups;
		File inputFile;
		FileReader reader;
		BufferedReader buffReader = null;

		logger.debug("readTestGroups:: started");
		inputFile = new File(testGroupFile);

		if (testGroupList == null || checkModified (inputFile.getParentFile(), inputFile.getName())) {
			testGroups = new StringBuilder();

			try {
				reader = new FileReader(inputFile);
				buffReader = new BufferedReader(reader);
				String line;

				while ((line = buffReader.readLine()) != null) {
					testGroups.append(line);

					if (!StringUtils.isEmpty(line)) {
						testGroups.append(STRING_COMMA);
					}
				}
			} catch (IOException e) {
				throw new RuntimeException(e);
			} finally {
				if (buffReader != null) {
					try {
						buffReader.close();
					} catch (IOException e) {
						throw new RuntimeException(e);
					}
				}
			}

			testGroupList = testGroups.toString();
		}

		logger.debug("testGroupList: " + testGroupList);
		logger.debug("readTestGroups:: finished.");
		return testGroupList;
	}

	public boolean checkModified (File folder, String fileName) {
		WatchService watcher;
		boolean modified = false;

		logger.debug("checkModified:: started");
		watcher = watcherService.getWatcher(folder.getAbsolutePath());

		try {
			logger.debug("checkModified:: calling watcer take");
			WatchKey key = watcher.poll();
			logger.debug("checkModified:: after watcer take key: " + key);

			if (key != null) {
				List<WatchEvent<?>> events = key.pollEvents();

				for (WatchEvent<?> event : events) {
					if (event.kind() == StandardWatchEventKinds.ENTRY_CREATE && fileName.equalsIgnoreCase(event.context().toString())) {
						modified = true;
					}

					if (event.kind() == StandardWatchEventKinds.ENTRY_MODIFY && fileName.equalsIgnoreCase(event.context().toString())) {
						modified = true;
					}
				}

				key.reset();
			}
		} catch (Exception e) {
			logger.error("An error occured while calling checkModified. Please check stack trace for more information.", e);
			throw new RuntimeException(e);
		}

		logger.debug("checking file for modification folder: " + folder.getAbsolutePath() + " fileName: " + fileName + " modified: " + modified);
		logger.debug("checkModified:: finished");
		return modified;
	}

}
