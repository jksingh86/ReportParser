package easyupload.service;

import static easyupload.utils.ApplicationConstants.STRING_FILES;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import easyupload.entity.FileUpload;

@Service
public class FileUploadService {
	@Value("${base.dir}")
	String baseDir;

	// Upload the file
	public void uploadFile(FileUpload doc) throws IOException {
		File parentDir = new File(baseDir.concat(File.separator).concat(doc.getUuid().concat(File.separator).concat(STRING_FILES)));

		if(!parentDir.exists()) {
			parentDir.mkdirs();
		}

		BufferedOutputStream stream = new BufferedOutputStream(
				new FileOutputStream(Paths.get(parentDir.getAbsolutePath().concat(File.separator).concat(doc.getFilename())).toFile()));
		stream.write(doc.getFile());
		stream.close();
	}
}
