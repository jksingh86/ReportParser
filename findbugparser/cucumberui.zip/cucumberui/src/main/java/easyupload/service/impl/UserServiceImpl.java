package easyupload.service.impl;

import easyupload.entity.User;
import easyupload.service.IUserService;

import org.springframework.stereotype.Component;

import easyupload.entity.LoginUser;

public class UserServiceImpl implements IUserService {

	public User getUser(LoginUser login) {
		return new User("Jitendra");
	}
}
