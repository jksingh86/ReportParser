package easyupload.service;

import static easyupload.utils.ApplicationConstants.STRING_COMMA;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.util.StringUtils;

import easyupload.utils.ApplicationUtils;

@Service
public class ServiceCaller {
	@Value("${automation.script}")
	String automationScript;

	public void callService(ServiceCall call) {
		String testGroupList = ApplicationUtils.listToString(call.getTestGroupList(), STRING_COMMA);

		if (StringUtils.isEmpty(testGroupList)) {
			testGroupList = "";
		}

		System.out.println(String.format("sh %s %s %s", automationScript, call.getUuid(), testGroupList));

//		try {
//			ApplicationUtils
//					.executeAsCommand(String.format("sh %s %s %s", automationScript, call.getUuid(), testGroupList));
//		} catch (FileNotFoundException | IOException e) {
//			throw new RuntimeException(e);
//		}
	}
}
