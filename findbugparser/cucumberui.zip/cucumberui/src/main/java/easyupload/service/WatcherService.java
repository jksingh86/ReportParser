package easyupload.service;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import easyupload.utils.ApplicationConstants;

public class WatcherService {
	private final Logger logger = LoggerFactory.getLogger(WatcherService.class);
	private String watchDirs;
	private Map<String, WatchService> watcherMap;

	public WatcherService(String watchDirs) {
		this.watchDirs = watchDirs;
		this.watcherMap = new HashMap<String, WatchService>();
	}

	public void registerPaths() {
		logger.info("watchDirs: " + watchDirs);
		String watchDirArray[] = watchDirs.split(ApplicationConstants.STRING_COMMA);

		for (String watchDir : watchDirArray) {
			Path testGroupPath = Paths.get(watchDir);

			try {
				WatchService watchService = testGroupPath.getFileSystem().newWatchService();
				testGroupPath.register(watchService, StandardWatchEventKinds.ENTRY_CREATE,
						StandardWatchEventKinds.ENTRY_DELETE, StandardWatchEventKinds.ENTRY_MODIFY);
				logger.info("registering path: " + testGroupPath.toFile().getAbsolutePath());
				watcherMap.put(testGroupPath.toFile().getAbsolutePath(), watchService);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public WatchService getWatcher(String dir) {
		return watcherMap.get(dir);
	}

	/*
	 * close all watcher while destroying bean
	 */
	public void destroy() throws Exception {
		watcherMap.forEach((k, v) -> {
			try {
				v.close();
			} catch (IOException e) {
				logger.info("An error occured while closing watcher: " + v, e);
				throw new RuntimeException(e);
			}
		}); 
	}

	public static void main(String[] args) {
		String dirString = "C:/work/ravindra/software/jetty/webapps/automation-dir/testcases";
		Path dir = Paths.get(dirString);
		WatcherService obj = new WatcherService(dirString);
		obj.registerPaths();
		WatchService service = obj.getWatcher(dir.toFile().getAbsolutePath());

		while (true) {
			try {
				Thread.sleep(10000);
				System.out.println("polling for events");
				WatchKey watckKey = service.poll();
				System.out.println("watckKey: " + watckKey);

				if (watckKey != null) {
					List<WatchEvent<?>> events = watckKey.pollEvents();
					System.out.println("events: " + events.size() + " events: " + events);

					for (WatchEvent<?> event : events) {
						if (event.kind() == StandardWatchEventKinds.ENTRY_CREATE) {
							System.out.println("Created: " + event.context().toString());
						}

						if (event.kind() == StandardWatchEventKinds.ENTRY_DELETE) {
							System.out.println("Delete: " + event.context().toString());
						}

						if (event.kind() == StandardWatchEventKinds.ENTRY_MODIFY) {
							System.out.println("Modify: " + event.context().toString());
						}
					}

					boolean valid = watckKey.reset();

					if (!valid) {
						break;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
