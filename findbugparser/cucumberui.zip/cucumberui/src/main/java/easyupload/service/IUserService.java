package easyupload.service;

import easyupload.entity.LoginUser;
import easyupload.entity.User;

public interface IUserService {

	public User getUser(LoginUser login);
}
