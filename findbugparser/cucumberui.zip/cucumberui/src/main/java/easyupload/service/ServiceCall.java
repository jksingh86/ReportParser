package easyupload.service;

import java.util.Date;
import java.util.List;

public class ServiceCall {
	private String uuid;
	private String status;
	private String user;
	private Date startDate;
	private Date endDate;
	private List<String> testGroupList;
	
	public ServiceCall() {
		super();
	}

	public ServiceCall(String uuid, String status, String user, Date startDate, Date endDate,
			List<String> testGroupList) {
		super();
		this.uuid = uuid;
		this.status = status;
		this.user = user;
		this.startDate = startDate;
		this.endDate = endDate;
		this.testGroupList = testGroupList;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public List<String> getTestGroupList() {
		return testGroupList;
	}

	public void setTestGroupList(List<String> testGroupList) {
		this.testGroupList = testGroupList;
	}

	@Override
	public String toString() {
		return "ServiceCall [uuid=" + uuid + ", status=" + status + ", user=" + user + ", startDate=" + startDate
				+ ", endDate=" + endDate + ", testGroupList=" + testGroupList + "]";
	}
}
