package easyupload.service;

import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Query;

import easyupload.entity.CucumberFeature;
import easyupload.entity.JUnitSuite;
import easyupload.entity.TestGroup;
import easyupload.persistence.ServiceCallPersistence;
import easyupload.utils.ApplicationConstants;
import jks.dao.TestCaseReportMongoRepository;
import jks.domain.TestCaseReport;

@Component
public class ServiceCallManager {
	private ExecutorService service;
	private boolean init = false;

	private ServiceCallPersistence serviceCallPersistence;
	private ServiceCaller serviceCaller;
	
	@Autowired
	private  TestCaseReportMongoRepository testCaseReportMongoRepository;
	
	public ServiceCallManager(ServiceCallPersistence serviceCallPersistence, ServiceCaller serviceCaller) {
		this.serviceCallPersistence = serviceCallPersistence;
		this.serviceCaller = serviceCaller;
		service = Executors.newSingleThreadExecutor();
		init();
	}

	public void init() {
		if (!init) {
			List<ServiceCall> list;
			list = serviceCallPersistence.listServiceCall(ApplicationConstants.STATUS_QUEUED);

			for (ServiceCall call : list) {
				submitServiceCall(call);
			}

			init = true;
		}
	}

	public List<ServiceCall> listAllServiceCall() {
		return serviceCallPersistence.listAllServiceCall();
	}

	public List<ServiceCall> listFilteredServiceCall(int start, int length) {
		Query query = new Query();
		query.skip(start);
	    query.limit(length);
        Pageable pageable = new PageRequest(start, length, Direction.ASC,"uiid");
        Page<TestCaseReport> tests =  testCaseReportMongoRepository.findAll(pageable);
        System.out.println("pageable : "+pageable.getPageSize());
        System.out.println("Testcasereport Size: "+ tests.getSize());
		return serviceCallPersistence.listFilteredServiceCall(start, length);
	}

	public int countServiceCall() {
		testCaseReportMongoRepository.count();
		return serviceCallPersistence.countServiceCall();
	}

	public String getStatus(String uuid) {
		TestCaseReport status = testCaseReportMongoRepository.findByUiid(uuid);
		return serviceCallPersistence.getStatus(uuid);
	}

	public List<TestGroup> listSelectedTestGroup(String uuid) {
		return serviceCallPersistence.listSelectedTestGroup(uuid);
	}

	public void submitServiceCall(ServiceCall call) {
		ServiceCallTask task;
		task = new ServiceCallTask(call);

		if (call.getStatus() != ApplicationConstants.STATUS_QUEUED) {
			call.setStatus(ApplicationConstants.STATUS_QUEUED);
		}

		call.setStartDate(new Date());
		TestCaseReport tsr = new TestCaseReport(call.getUuid(),call.getStatus(),call.getUser(),call.getStartDate(),call.getEndDate(),call.getTestGroupList());
		testCaseReportMongoRepository.save(tsr);
		serviceCallPersistence.save(call);
		service.execute(task);
	}

	public void shutdown() {
		service.shutdown();
	}

	class ServiceCallTask implements Runnable {
		private ServiceCall call;

		public ServiceCallTask(ServiceCall call) {
			this.call = call;
		}

		@Override
		public void run() {
			// set status to RUNNING
			call.setStatus(ApplicationConstants.STATUS_RUNNING);
			serviceCallPersistence.save(call);
			TestCaseReport tsr = testCaseReportMongoRepository.findByUiid(call.getUuid());
			tsr.setStatus(ApplicationConstants.STATUS_RUNNING);
			tsr = testCaseReportMongoRepository.save(tsr);
			try {
				// call service
				serviceCaller.callService(call);
			} finally {
				// set status to COMPLETED
				call.setEndDate(new Date());
				call.setStatus(ApplicationConstants.STATUS_COMPLETED);
				tsr.setEnd_time(new Date());
				tsr.setStatus(ApplicationConstants.STATUS_COMPLETED);
				tsr = testCaseReportMongoRepository.save(tsr);
				serviceCallPersistence.save(call);
			}
		}
	}
}
