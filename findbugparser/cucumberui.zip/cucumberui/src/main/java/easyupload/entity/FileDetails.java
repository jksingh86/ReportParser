package easyupload.entity;

public class FileDetails {
	private String name;
	private String value;
	private String path;
	private String helpTxt;

	public FileDetails (String name, String value) {
		super();
		this.name = name;
		this.value = value;
	}

	public FileDetails(String name, String value, String path, String helpTxt) {
		super();
		this.name = name;
		this.value = value;
		this.path = path;
		this.helpTxt = helpTxt;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getHelpTxt() {
		return helpTxt;
	}

	public void setHelpTxt(String helpTxt) {
		this.helpTxt = helpTxt;
	}

	@Override
	public String toString() {
		return "FileDetails [name=" + name + ", value=" + value + ", path=" + path + ", helpTxt=" + helpTxt + "]";
	}

}
