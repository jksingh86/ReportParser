package easyupload.entity;

public class SessionAttributes {

	private String user;

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "SessionAttributes [user=" + user + "]";
	}
}
