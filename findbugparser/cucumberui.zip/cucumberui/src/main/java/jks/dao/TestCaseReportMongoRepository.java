package jks.dao;

import jks.domain.TestCaseReport;
import org.springframework.data.mongodb.repository.MongoRepository;
 
public interface TestCaseReportMongoRepository extends MongoRepository<TestCaseReport, Integer> {
	TestCaseReport findByUiid(String uiid);
	TestCaseReport findByStatus(String status);
	TestCaseReport findByUser(String user);
}