package jks.domain;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import easyupload.service.ServiceCall;
import easyupload.utils.RandomUtil;
 
@Document(collection = "TestCaseReport")
public class TestCaseReport  {
    @Id
    protected String id;
    private String uiid;
    private String status;
    private String user;
    private Date start_time;
    private Date end_time;
    private List<String> test_group_ids;
    
    public TestCaseReport () {
    }
    
	public TestCaseReport(String uiid, String status, String user, Date start_time, Date end_time,
			List<String> groupList) {
		super();
		this.id  = RandomUtil.getUUID();
		this.uiid = uiid;
		this.status = status;
		this.user = user;
		this.start_time = start_time;
		this.end_time = end_time;
		this.test_group_ids = groupList;
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUiid() {
		return uiid;
	}
	public void setUiid(String uiid) {
		this.uiid = uiid;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public Date getStart_time() {
		return start_time;
	}
	public void setStart_time(Date start_time) {
		this.start_time = start_time;
	}
	public Date getEnd_time() {
		return end_time;
	}
	public void setEnd_time(Date end_time) {
		this.end_time = end_time;
	}
	
	public List<String> getTest_group_ids() {
		return test_group_ids;
	}

	public void setTest_group_ids(List<String> test_group_ids) {
		this.test_group_ids = test_group_ids;
	}

	public static TestCaseReport valueOf(ServiceCall sc) {
		return new TestCaseReport(sc.getUuid(), sc.getStatus(), sc.getUser(), sc.getStartDate(),
				sc.getEndDate(), sc.getTestGroupList());
	}
	
	@Override
	public String toString() {
		return "User [id=" + id + ", uiid=" + uiid + ", status=" + status + ", user=" + user + ", start_time="
				+ start_time + ", end_time=" + end_time + ", test_group_ids=" + test_group_ids + "]";
	}
 
   
}