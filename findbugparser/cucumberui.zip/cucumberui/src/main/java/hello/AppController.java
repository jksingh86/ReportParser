package hello;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import entity.JobInfo;
import entity.Schedule;

@RestController
public class AppController {

	@RequestMapping(value = "/jobInfo", method = RequestMethod.GET)
	public List<JobInfo> jobInfo() {
		return Arrays.asList(new JobInfo("<div>R<br/>T<div>", "col2", "o1", Arrays.asList(new Schedule("S1"),new Schedule("S2")), "1"));
	}

}
