/* js/fileAppDirectives */

function dropzone() {
    return function(scope, element, attrs) {
        var config = {
            url: 'upload',
            maxFilesize: 10000,
            paramName: "uploadfile",
            maxThumbnailFilesize: 10,
			maxFiles: 100,
			parallelUploads: 100,
			uploadMultiple: true,
            autoProcessQueue: false
        };

        var eventHandlers = {
            'addedfile': function(file) {
                //scope.file = file;
                // if (this.files[1]!=null) {
                    //this.removeFile(this.files[0]);
                // }
				//console.log(this.files);
                //scope.$apply(function() {
                //    scope.fileAdded = true;
                //});
            },
            'success': function (file, response) {
            	uuid = response.uuid;
            },
			'sending': function(file, xhr, formData) {
				var name = "uploadfile-"+Math.random();
				formData.append(name, file);
			},
			'queuecomplete': function (file) {
				// console.log('queuecomplete');
				// startLogging();
			}, 
			'successmultiple': function (files, response) {
				uuid = response.uuid;
				startLogging();
            }
        };

        dropzone = new Dropzone(element[0], config);

        angular.forEach(eventHandlers, function(handler, event) {
            dropzone.on(event, handler);
        });

        scope.processDropzone = function() {
        	if (dropzone.getQueuedFiles().length > 0) {
        		dropzone.processQueue();  
        	} else {
        		console.log('submitting empty files');
        		dropzone.uploadFiles([]); 
        	}                                    
        };

        scope.resetDropzone = function() {
            dropzone.removeAllFiles();
        }
    }
}

angular.module('fileApp').directive('dropzone', dropzone);