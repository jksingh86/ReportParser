var contextPath;
var queryString;
var testcasesRootDir = '/automation-dir/test-cases/';
var supportFileDir = '/automation-dir/supportFiles/';
var sampleFileDir = '/automation-dir/sample/';

function getContextPath() {
	var pathname = window.location.pathname;
	pathname = pathname.substring(0, pathname.indexOf("/web"));
	return pathname;
}

queryString = window.location.search;
contextPath = getContextPath();
