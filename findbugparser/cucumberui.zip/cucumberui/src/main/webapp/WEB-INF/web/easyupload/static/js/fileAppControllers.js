/* js/fileAppControllers.js */

function fileCtrl ($scope) {
    $scope.partialDownloadLink = 'download?filename=';
    $scope.filename = '';

    $scope.uploadFile = function() {
    	$("#selectedTestGroupsHidden").val($("#selectedTestGroup").val());
    	console.log('selectedTestGroup: [' + $("#selectedTestGroup").val() + ']');
        $scope.processDropzone();
    };

    $scope.reset = function() {
        $scope.resetDropzone();
        moveAllTestGroups($('#selectedTestGroup'), $('#availableTestGroup'));
    };
}

angular.module('fileApp').controller('fileCtrl', fileCtrl);
