angular.module('fileApp', []);

Dropzone.autoDiscover = false;
var uuid;

var intervalId = "";
var reqStatus;

function startLogging() {
	$("#statusId").html("<i class=\"fa fa-spinner fa-spin fa-3x fa-fw\" style=\"color:green\"></i>&nbsp;<span>Working...</span>");
	intervalId = setInterval(fetchLogs, 500);
	$("#referenceId").html("&nbsp;"+uuid);
	disableDropzone();
}

function fetchLogs() {
	getStatus();
	$("#log-container").show();

	if (reqStatus == 'COMPLETED') {
		//console.log('clearingInterval intervalId: ' + intervalId);
		clearInterval(intervalId);
		$("#completed-container").show();
		$("#log-container").hide();
		$("#queue-container").hide();

		var containerHtml = "<div class=\"dropzone\">"+
							"&nbsp;&nbsp;<i class=\"fa fa-file\" style=\"color:green\" aria-hidden=\"true\"></i>&nbsp;<a target=\"_blank\" href=\""+testcasesRootDir+uuid+"/report/\">View Report</a></div>";

		$("#completed-container").html(containerHtml);
		$("#statusId").html("<i class=\"fa fa-check-circle\" style=\"color:green\" aria-hidden=\"true\"></i>&nbsp;<span>Test executed.</span>");
	} else if (reqStatus == 'RUNNING') {
		getLogs();
		$("#completed-container").hide();
		$("#log-container").show();
		$("#queue-container").hide();

		$("#statusId").html("<i class=\"fa fa-spinner fa-spin fa-3x fa-fw\" style=\"color:green\"></i>&nbsp;<span>In progress...</span>");
		//console.log('fetching log for uuid: ' + uuid+ ' reqStatus: ' + reqStatus + ' intervalId: ' + intervalId);
	} else if (reqStatus == 'QUEUED') {
		$("#completed-container").hide();
		$("#log-container").hide();
		$("#queue-container").show();

		$("#statusId").html("<i class=\"fa fa-spinner fa-spin fa-3x fa-fw\" style=\"color:green\"></i>&nbsp;<span>Test queued...</span>");
	} else {
		//console.log('uuid: ' + uuid+ ' reqStatus: ' + reqStatus);
	}
}

function getStatus() {
	$.ajax({url: "getstatus/"+uuid, success: function (result) {
		reqStatus = result;
    }});
}

function getLogs() {
	$.ajax({url: testcasesRootDir + uuid + "/cucumber.log", success: function(result) {
		var logContainerDiv = $("#log-container");
		logContainerDiv.html("<div class=\"dropzone\">"+result+"</div>");
		var elem = document.getElementById('log-container');
		elem.scrollTop = elem.scrollHeight;
    }});
}

$(document).ready(function() {
	$(function(){
		$.ajax({
			url: "listTestGroup", 
				success: function(data) {
					data = JSON.parse(data);
					var sel = $("#availableTestGroup");
		    		sel.empty();
		    		for (var i=0; i<data.length; i++) {
		      			sel.append('<option value="' + data[i].value + '">' + data[i].name + '</option>');
		    		}
		    		$('#availableTestGroup').filterByText($('#filterAvailableTestGroup'), $('#clearFilterAvailableTestGroup'));
				}
		});
	});

	$( function() {
        $( "#popupTestGroupDialog" ).dialog({width: 800, height: 450});
        $( "#popupTestGroupDialog" ).dialog('close');
	} );        

	$('#selectTestGroup').click(function() {  
	    $("#popupTestGroupDialog").dialog('open');
	});  

	$('#addTestGroup').click(function() {
		var selectedOptions = $('#availableTestGroup option:selected');

		// move options
		!$(selectedOptions).remove().appendTo('#selectedTestGroup');
		updateData(selectedOptions, $('#availableTestGroup'), $('#selectedTestGroup'));
	    return sortTestGroup();
	});  

	$('#removeTestGroup').click(function() {
		var selectedOptions = $('#selectedTestGroup option:selected');
		
		// move options
		!$(selectedOptions).remove().appendTo('#availableTestGroup');

		updateData(selectedOptions, $('#selectedTestGroup'), $('#availableTestGroup'));
		return sortTestGroup();
	});  

	$('#clearFilterAvailableTestGroup').click(function() {
		$('#filterAvailableTestGroup').val('');
		updateFilter($('#filterAvailableTestGroup'), $('#availableTestGroup'));
		$('#clearFilterAvailableTestGroup').hide();
	});

	$('#clearFilterSelectedTestGroup').click(function() {
		$('#filterSelectedTestGroup').val('');
		updateFilter($('#filterSelectedTestGroup'), $('#selectedTestGroup'));
		$('#clearFilterSelectedTestGroup').hide();
	});

	$('#closeTestGroupDialogue').click(function() {
		$("#popupTestGroupDialog").dialog('close');
	});

	$('#clearFilterAvailableTestGroup').hide();
	$('#clearFilterSelectedTestGroup').hide();
	
	$('#checkSelectedTestGroup').hide();
	$("#completed-container").hide();
	$("#queue-container").hide();
	$("#log-container").hide();

	// for view execution
	if (queryString && queryString.length > 0) {
		disableDropzone();

		console.log('disabling double click');

		$("#availableTestGroup").dblclick(function(e){
		    e.preventDefault();
		});

		$("#selectedTestGroup").dblclick(function(e){
		    e.preventDefault();
		});

		var urlParams = new URLSearchParams(queryString);
		uuid = urlParams.get('uuid');
		startLogging();
	} else {
		$("#availableTestGroup").on("dblclick", function(e){
			$('#addTestGroup').click();
	        e.preventDefault();
	    });

		$("#selectedTestGroup").on("dblclick", function(e){
			$('#removeTestGroup').click();
	        e.preventDefault();
	    });
	}

	$(function getSelectedTestGroups() {
		if (uuid) {
			$.ajax({url: "selectedTestGroups/"+uuid, success: function (result) {
				result = JSON.parse(result);
				$("#availableTestGroup > option").each(function() {
				    for (var i=0; i<result.length; i++) {
				    	if (this.value == result[i].value) {
				    		!$(this).remove().appendTo('#selectedTestGroup');
				    		$('#checkSelectedTestGroup').show();
				    	}
		    		}
				});
		    }});
		}

		$('#selectedTestGroup').filterByText($('#filterSelectedTestGroup'), $('#clearFilterSelectedTestGroup'));
	});
});

function sortTestGroup() {
    var sel = $('#availableTestGroup');
    var opts_list = sel.find('option');
    opts_list.sort(function(a, b) { return $(a).text() > $(b).text() ? 1 : -1; });
    sel.html('').append(opts_list);

    var sel = $('#selectedTestGroup');
    var opts_list = sel.find('option');
    opts_list.sort(function(a, b) { return $(a).text() > $(b).text() ? 1 : -1; });
    sel.html('').append(opts_list);

    if ($(sel).val() == '') {
    	$('#checkSelectedTestGroup').hide();
    } else {
    	$('#checkSelectedTestGroup').show();
    }
}

function moveAllTestGroups(sourceElm, targetElm) {
	$(sourceElm).find("option").each(function() {
		!$(this).remove().appendTo(targetElm);
    });

	updateData($(sourceElm).find("option"), sourceElm, targetElm);
	return sortTestGroup();
}

function disableDropzone() {
	$("#executeTest").prop("disabled",true);
	$("#reset").prop("disabled",true);
	$("#addTestGroup").prop("disabled",true);
	$("#removeTestGroup").prop("disabled",true);
	$(".dz-hidden-input").prop("disabled",true);
	dropzone.disable();
}

function updateData(selectedOptions, sourceElem, targetElem) {
	var dataOptions = $(sourceElem).data('options');
	console.log('selectedOptions: ' + selectedOptions + ' sourceElem: ' + sourceElem + ' targetElem: ' + targetElem + ' dataOptions: ' + dataOptions);
	
	// repopulate source data attribute
    for (var i=0; i<selectedOptions.length; i++) {
    	dataOptions = jQuery.grep(dataOptions, function(item) {
    		return item.value != selectedOptions[i].value;
    	});
	}

    $(sourceElem).data('options', dataOptions);
    dataOptions = $(targetElem).data('options');
    console.log(' targetElem: ' + targetElem + ' dataOptions: ' + dataOptions);

    // repopulate target data attribute
    for (var i=0; i<selectedOptions.length; i++) {
    	dataOptions.push({
        	value: $(selectedOptions[i]).val(),
        	text: $(selectedOptions[i]).text()
      	});
	}

    $(targetElem).data('options', dataOptions);
}

function updateFilter(textbox, selectbox, cleartextbox) {
  	var options = $(selectbox).empty().data('options');
  	var search = $.trim($(textbox).val());
  	var regex = new RegExp(search, "gi");
  	console.log('textbox: ' + textbox + ' selectbox: ' + selectbox + ' cleartextbox: ' + cleartextbox);

  	$.each(options, function(i) {
    	var option = options[i];
    	if (option.text.match(regex) !== null || search=='') {
      		$(selectbox).append($('<option>').text(option.text).val(option.value));
    	}
  	});
} 
jQuery.fn.filterByText = function(textbox, cleartextbox) {
	return this.each(function() {
	    var select = this;
	    var options = [];
	    $(select).find('option').each(function() {
	      	options.push({
	        	value: $(this).val(),
	        	text: $(this).text()
	      	});
	    });

	    console.log('setting  options: ' + options + ' select: ' + $(select).attr('name'));
	    $(select).data('options', options);

	    $(textbox).bind('input propertychange paste', function() {
	      	var options = $(select).empty().data('options');
	      	var search = $.trim($(this).val());
	      	var regex = new RegExp(search, "gi");

	      	if (search.length == 0) {
	      		$(cleartextbox).hide();
	      	} else {
	      		$(cleartextbox).show();
	      	}

	      	$.each(options, function(i) {
	        	var option = options[i];
	        	if (option.text.match(regex) !== null || search=='') {
	          		$(select).append($('<option>').text(option.text).val(option.value));
	        	}
	      	});
	    });
	  	});
	};
	
jQuery.fn.setActive = function(ulId,className) {
	$('#'+ulId).each(function(){
        // this is inner scope, in reference to the .phrase element
        var phrase = '';
        $(this).find('li').each(function(){
            $(this).removeClass(className);
        });
        $(this).addClass(className);
    });
}